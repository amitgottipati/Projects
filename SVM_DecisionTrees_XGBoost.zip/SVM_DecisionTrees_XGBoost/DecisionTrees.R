###################################################
########## Decision Trees
################################################


####################################
########### Dataset 1
##################################

rm(list=ls(all=TRUE))

data = read.csv("C:\\Users\\19726\\Desktop\\sgemm_product_dataset\\sgemm_product.csv")
head(data)
summary(data)

## creating our target variable
data$avg=rowMeans(data[,15:18])

## removing the 4 different run times
data$Run1..ms.=NULL
data$Run2..ms.=NULL
data$Run3..ms.=NULL
data$Run4..ms.=NULL

##converting our target variable to binary
data$avg = ifelse(data$avg>median(data$avg),1,0)

str(data)

### converting our variables to factors
for (i in 1:ncol(data)){
  data[,i]=as.factor(data[,i])
}

str(data)

#### splitting the data set into test and train
set.seed(101) # Set Seed so that same sample can be reproduced in future also
# Now Selecting 70% of data as sample from total 'n' rows of the data  
sample <- sample.int(n = nrow(data), size = floor(.70*nrow(data)), replace = F)
train <- data[sample, ]
test  <- data[-sample, ]

head(train)
str(train)

library(rpart)
library(rattle)
library(rpart.plot)
library(RColorBrewer)

##############################
#### without cross validation
##############################

## start clock
start_time=Sys.time()
set.seed(100)
### gini index decision tree 
tree_gini=rpart(
  avg ~ ., ## formulae for tree
  data = train,
  method = "class", ## class for classification tree and anova for regression trees
  parms = list(split = 'gini'),
  control = list(maxdepth = 7) ## max depth of tree
  ## cp=-1 , use this for full grown tree, this may overfit
  )
# Stop the clock
end_time=Sys.time()
## time elapsed calculation
time_elapsed=end_time-start_time
time_elapsed

### pred
## train error
predginitr=predict(tree_gini,train[,-15],type = "class")
predginitr

acc=confusionMatrix(predginitr,as.factor(train[,15]),positive = "1")
acc

Train_error=1-acc$overall ## just checking the accuracy (here Acc will convert to error)
Train_error

## test error
predgini=predict(tree_gini,test[,-15],type = "class")
predgini

acc=confusionMatrix(predgini,as.factor(test[,15]),positive = "1")
acc

Test_error=1-acc$overall ## just checking the accuracy (here Acc will convert to error)
Test_error

tree_gini$variable.importance

fancyRpartPlot(tree_gini, caption = "Gini Split, Depth=7")

printcp(tree_gini)

plotcp(tree_gini)

summary(tree_gini)

####################################################
################ with cross validation
##################################################

## start clock
start_time=Sys.time()
set.seed(100)
# Set up caret to perform 10-fold cross validation repeated 3 times
caret.control <- trainControl(method = "repeatedcv",
                              number = 10,
                              repeats = 3)


# Use caret to train the rpart decision tree using 10-fold cross 
# validation repeated 3 times and use 15 values for tuning the
# cp parameter for rpart. This code returns the best model trained
# on all the data
set.seed(100)
rpart.cv <- train(avg ~ ., 
                  data = train,
                  method = "rpart",
                  trControl = caret.control,
                  tuneLength = 15)

# Stop the clock
end_time=Sys.time()
## time elapsed calculation
time_elapsed=end_time-start_time
time_elapsed

rpart.cv

rpart.best <- rpart.cv$finalModel

## train error
predginitr=predict(rpart.cv,train[,-15],type = "raw")
predginitr

print(length(predginitr))
print(head(predginitr))

acc=confusionMatrix(as.factor(predginitr),as.factor(train[,15]),positive = "1")
acc

Train_error=1-acc$overall ## just checking the accuracy (here Acc will convert to error)
Train_error

## test error
predgini=predict(rpart.cv,test[,-15],type = "raw")
predgini

print(length(predgini))

acc=confusionMatrix(predgini,as.factor(test[,15]),positive = "1")
acc

Test_error=1-acc$overall ## just checking the accuracy (here Acc will convert to error)
Test_error

rpart.best$variable.importance

fancyRpartPlot(rpart.best, caption = "Gini Split, rpart-best-model, Depth=9")

printcp(rpart.best)



summary(rpart.best)


#############################################################################
##################### Dataset 2
#############################################################################

rm(list=ls(all=TRUE))

data2=read.csv("C:\\Users\\19726\\Desktop\\Applied Machine Learning\\Assignment-2\\weatherAUS.csv")

head(data2)
str(data2)
summary(data2)

## Given in the dataset that the RISK_MM variable should be removed as 
## Not excluding it will leak the answers to your model and reduce its predictability.
data2$RISK_MM=NULL

data2$Temp3pm=NULL
data2$Temp9am=NULL
data2$Date=NULL

str(data2)

#### splitting the data set into test and train
set.seed(101) # Set Seed so that same sample can be reproduced in future also
# Now Selecting 70% of data as sample from total 'n' rows of the data  
sample <- sample.int(n = nrow(data2), size = floor(.70*nrow(data2)), replace = F)
train <- data2[sample, ]
test  <- data2[-sample, ]

str(train)

colSums(is.na(data2))

#############################################
###### Without Cross validation
###########################################

## start clock
start_time=Sys.time()
set.seed(100)
### gini index decision tree 
tree_gini=rpart(
  RainTomorrow ~ ., ## formulae for tree
  data = train,
  method = "class", ## class for classification tree and anova for regression trees
  parms = list(split = 'gini'),
  control = list(maxdepth = 7) ## max depth of tree
  ## cp=-1 , use this for full grown tree, this may overfit
  ##The cp value is a stopping parameter. It helps speed up the search for splits because 
  ##it can identify splits that don’t meet this criteria and prune them before going too far.
)
# Stop the clock
end_time=Sys.time()

## time elapsed calculation
time_elapsed=end_time-start_time
time_elapsed

### pred

## train error
predginitr=predict(tree_gini,train[,-20],type = "class")
predginitr

acc=confusionMatrix(predginitr,as.factor(train[,20]),positive = "Yes")
acc

Train_error=1-acc$overall ## just checking the accuracy (here Acc will convert to error)
Train_error

## test error
predgini=predict(tree_gini,test[,-20],type = "class")
predgini

acc=confusionMatrix(predgini,as.factor(test[,20]),positive = "Yes")
acc

Test_error=1-acc$overall ## just checking the accuracy (here Acc will convert to error)
Test_error

tree_gini$variable.importance

fancyRpartPlot(tree_gini, caption = "Gini Split, Depth=7")

printcp(tree_gini)

plotcp(tree_gini)

##################################################################
################### with cross Validation
##########################################################

## Removing variables with lot of missing values
data2$Evaporation=NULL
data2$Sunshine=NULL

library(zoo)
## imputing numerical variables with previous values as it is time series data.
data2=na.locf(data2,fromLast=TRUE)

colSums(is.na(data2))
str(data2)

#### splitting the data set into test and train
set.seed(101) # Set Seed so that same sample can be reproduced in future also
# Now Selecting 70% of data as sample from total 'n' rows of the data  
sample <- sample.int(n = nrow(data2), size = floor(.70*nrow(data2)), replace = F)
train <- data2[sample, ]
test  <- data2[-sample, ]

## start clock
start_time=Sys.time()
set.seed(100)
# Set up caret to perform 10-fold cross validation repeated 3 times
caret.control <- trainControl(method = "repeatedcv",
                              number = 10,
                              repeats = 3)


# Use caret to train the rpart decision tree using 10-fold cross validation repeated 3 times and use 15 values for tuning the
# cp parameter for rpart. This code returns the best model trained on all the data

rpart.cv <- train(RainTomorrow ~ ., 
                  data = train,
                  method = "rpart",
                  trControl = caret.control,
                  tuneLength = 15)

# Stop the clock
end_time=Sys.time()
## time elapsed calculation
time_elapsed=end_time-start_time
time_elapsed

rpart.cv

rpart.best <- rpart.cv$finalModel

## train error
predginitr=predict(rpart.cv,train[,-18],type = "raw")
head(predginitr)

print(length(predginitr))
print(head(predginitr))

acc=confusionMatrix(as.factor(predginitr),as.factor(train[,18]),positive = "Yes")
acc

Train_error=1-acc$overall ## just checking the accuracy (here Acc will convert to error)
Train_error

## test error
predgini=predict(rpart.cv,test[,-18],type = "raw")
predgini

print(length(predgini))

acc=confusionMatrix(predgini,as.factor(test[,18]),positive = "Yes")
acc

Test_error=1-acc$overall ## just checking the accuracy (here Acc will convert to error)
Test_error

rpart.best$variable.importance

fancyRpartPlot(rpart.best, caption = "Gini Split, rpart-best-model, Depth=11")

printcp(rpart.best)


summary(rpart.best)


#######################################################################
