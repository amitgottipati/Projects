###############################################################################
###############################################################################
##### xgboost dataset1
###############################################################################
###############################################################################

library(xgboost)
library(caret)
library(tidyverse)
install.packages("drat", repos="https://cran.rstudio.com")
drat:::addRepo("dmlc")

rm(list=ls(all=TRUE))

data = read.csv("C:\\Users\\19726\\Desktop\\sgemm_product_dataset\\sgemm_product.csv")
head(data)
summary(data)

## creating our target variable
data$avg=rowMeans(data[,15:18])

## removing the 4 different run times
data$Run1..ms.=NULL
data$Run2..ms.=NULL
data$Run3..ms.=NULL
data$Run4..ms.=NULL

##converting our target variable to binary
data$avg = ifelse(data$avg>median(data$avg),1,0)


str(data)
summary(data)
## checking our target variable
table(data$avg)

#### splitting the data set into test and train
set.seed(101) # Set Seed so that same sample can be reproduced in future also
# Now Selecting 70% of data as sample from total 'n' rows of the data  
sample <- sample.int(n = nrow(data), size = floor(.70*nrow(data)), replace = F)
train <- data[sample, ]
test  <- data[-sample, ]

head(train)
str(train)

# training data
train=as.matrix(train)
train_labels=labels(train)

# testing data
test=as.matrix(test)
test_labels=labels(test)

str(train)

# put our testing & training data into two seperates Dmatrixs objects
dtrain <- xgb.DMatrix(data = train[,1:14], label= train[,15])

dtest <- xgb.DMatrix(data = test[,1:14], label= test[,15])

### Run from start_time to till end_time in one shot
## start the clock
start_time=Sys.time()

set.seed(100)
xgbmodel1 <- xgboost(data = dtrain, # the data   ,
                    nround = 10, # max number of boosting iterations,
                    eta = 0.5, # controls learning rate  ,range=[0,1]
                    subsample = 0.6, ##contols no of samples supplied to a tree, range=(0,1)
                    colsample_bytree = 0.6,## controls no of features supplied to a tree, range=(0,1)
                    max_depth = 10, ## controls depth of tree
                    objective = "binary:logistic")  

# Stop the clock
end_time=Sys.time()

## time elapsed calculation
time_elapsed=end_time-start_time
time_elapsed

predxgb1=predict(xgbmodel1,test[,1:14])

print(length(predxgb1))
print(head(predxgb1))

predictionsxgb1=as.numeric(predxgb1>0.5,1,0)
predictionsxgb1

acc=confusionMatrix(as.factor(predictionsxgb1),as.factor(test[,15]),positive = "1")
acc

Test_error=1-acc$overall ## just checking the accuracy (here it will convert to error)
Test_error 


####################################
###### Xgboost with Cross validation
###################################

## start the clock
start_time=Sys.time()

set.seed(100)
cvxgb1=xgb.cv(data = dtrain, # the data with lables,
              nfold=5, ## the no of folds rquired for cross validation
              nround = 10, # max number of boosting iterations,
              eta = 0.5, # controls learning rate  ,range=[0,1]
              subsample = 0.6, ##contols no of samples supplied to a tree, range=(0,1)
              colsample_bytree = 0.6,## controls no of features supplied to a tree, range=(0,1)
              max_depth = 10, ## controls depth of tree
              objective = "binary:logistic")  

# Stop the clock
end_time=Sys.time()

## time elapsed calculation
time_elapsed=end_time-start_time
time_elapsed




###############################################################################
###############################################################################
##### xgboost dataset2
###############################################################################
###############################################################################
rm(list=ls(all=TRUE))

data2=read.csv("C:\\Users\\19726\\Desktop\\Applied Machine Learning\\Assignment-2\\weatherAUS.csv")

head(data2)
str(data2)
summary(data2)

## Given in the dataset that the RISK_MM variable should be removed as 
## Not excluding it will leak the answers to your model and reduce its predictability.
data2$RISK_MM=NULL

## checking for class imbalance
plot(data2$RainTomorrow,col="blue",main=" Rain Occurence ",ylab="Frequency")
table(data2$RainTomorrow)

data2$RainToday=ifelse(data2$RainToday=="Yes",1,0)
data2$RainTomorrow=ifelse(data2$RainTomorrow=="Yes",1,0)
data2$Date=NULL

## finding correlation between the numerical variables
library(Hmisc)
library(corrplot)

data_corr=rcorr(as.matrix(data2[,c("MinTemp","MaxTemp","Rainfall","Evaporation","Sunshine","WindGustSpeed","WindSpeed9am","WindSpeed3pm","Humidity9am","Humidity3pm","Pressure9am","Pressure3pm","Cloud9am","Cloud3pm","Temp9am","Temp3pm","RainToday")]))
data.coeff = data_corr$r
data.coeff
corrplot(as.matrix(data.coeff))

## we can see that Temp9am is highly correlated with MinTemp
## and Temp3pm is highly correlated with MaxTemp, hence dropping those variables

data2$Temp3pm=NULL
data2$Temp9am=NULL

## creating dummies for categorical variables
data2 <- fastDummies::dummy_cols(data2, select_columns = c("Location","WindGustDir","WindDir9am","WindDir3pm"))

str(data2)
## removing intital categorical variables used for dummification
data2$Location=NULL
data2$WindGustDir=NULL
data2$WindDir3pm=NULL
data2$WindDir9am=NULL

str(data2)

## Finding NA's 
sum(is.na(data2))
colSums(is.na(data2))

str(data2)
summary(data2)
#### splitting the data set into test and train
set.seed(101) # Set Seed so that same sample can be reproduced in future also
# Now Selecting 70% of data as sample from total 'n' rows of the data  
sample <- sample.int(n = nrow(data2), size = floor(.70*nrow(data2)), replace = F)
train <- data2[sample, ]
test  <- data2[-sample, ]

head(train)
str(train)

# training data
train=as.matrix(train)
train_labels=labels(train)

# testing data
test=as.matrix(test)
test_labels=labels(test)

str(train)

# put our testing & training data into two seperates Dmatrixs objects
dtrain <- xgb.DMatrix(data = train[,-16], label= train[,16])

dtest <- xgb.DMatrix(data = test[,-16], label= test[,16])

## start the clock
start_time=Sys.time()
set.seed(100)
xgbmodel <- xgboost(data = dtrain, # the data   ,
                    nround = 10, # max number of boosting iterations,
                    eta = 0.5, # controls learning rate  ,range=[0,1]
                    subsample = 0.6, ##contols no of samples supplied to a tree, range=(0,1)
                    colsample_bytree = 0.6,## controls no of features supplied to a tree, range=(0,1)
                    #max_depth = 40, ## controls depth of tree
                    objective = "binary:logistic")  

# Stop the clock
end_time=Sys.time()

## time elapsed calculation
time_elapsed=end_time-start_time
time_elapsed

predxgb=predict(xgbmodel,test[,-16])

print(length(predxgb))
print(head(predxgb))

predictionsxgb=as.numeric(predxgb>0.5,1,0)
predictionsxgb

acc=confusionMatrix(as.factor(predictionsxgb),as.factor(test[,16]),positive = "1")
acc

Test_error=1-acc$overall ## just checking the accuracy (here it will convert to error)
Test_error



####################################
###### Xgboost with Cross validation
###################################


## start the clock
start_time=Sys.time()

set.seed(100)
cv.res=xgb.cv(data = dtrain, # the data with lables,
              nfold=5, ## the no of folds rquired for cross validation
              nround = 10, # max number of boosting iterations,
              eta = 0.5, # controls learning rate  ,range=[0,1]
              subsample = 0.6, ##contols no of samples supplied to a tree, range=(0,1)
              colsample_bytree = 0.6,## controls no of features supplied to a tree, range=(0,1)
              #max_depth = 40, ## controls depth of tree
              objective = "binary:logistic")  

# Stop the clock
end_time=Sys.time()

## time elapsed calculation
time_elapsed=end_time-start_time
time_elapsed




###########################################################


