################################################
###### SVM
##### Amit Gottipati
#############################################

######################################################
################# SVM
###################################################
####### dataset1
#######################

rm(list=ls(all=TRUE))

data = read.csv("C:\\Users\\19726\\Desktop\\sgemm_product_dataset\\sgemm_product.csv")
head(data)
summary(data)

## taking sample as dataset is too large
data=data[sample(nrow(data), 30000), ]

## creating our target variable
data$avg=rowMeans(data[,15:18])

## removing the 4 different run times
data$Run1..ms.=NULL
data$Run2..ms.=NULL
data$Run3..ms.=NULL
data$Run4..ms.=NULL

##converting our target variable to binary
data$avg = ifelse(data$avg>median(data$avg),1,0)

str(data)

## Normalizing the data
for (i in 1:14) {
  data[,i] <- (data[,i] - mean(data[,i])) / sd(data[,i])
}

str(data)

### converting our variables to factors
for (i in 1:ncol(data)){
  data[,i]=as.factor(data[,i])
}

str(data)
head(data)

table(data$avg)

#### splitting the data set into test and train
set.seed(101) # Set Seed so that same sample can be reproduced in future also
# Now Selecting 70% of data as sample from total 'n' rows of the data  
sample <- sample.int(n = nrow(data), size = floor(.70*nrow(data)), replace = F)
train <- data[sample, ]
test  <- data[-sample, ]

library(e1071)

##############################################################################
#################### without cross validation
#################################################################

##start the clock
start_time=Sys.time()
set.seed(100)

linear_svm = svm(avg~., data=train, kernel="linear", gamma=0, cost=1)

# Stop the clock
end_time=Sys.time()
## time elapsed calculation
time_elapsed=end_time-start_time
time_elapsed


##train error
library(caret)
train_pred=predict(linear_svm,train[,-15])

length(train_pred)
head(train_pred)
head(train$avg)

acc=confusionMatrix(as.factor(train_pred),as.factor(train[,15]),positive = "1")
acc

trainerror=1-acc$overall
trainerror

## test error
test_pred=predict(linear_svm,test[,-15])

acc=confusionMatrix(test_pred,as.factor(test[,15]),positive = "1")
acc

testerror=1-acc$overall
testerror


#############################################
################# with cross validation'
#################################################

##start the clock
start_time=Sys.time()
set.seed(100)

### cross validation
set.seed(123)
svm.cv <- train(
  avg~., data = train, method = "svmLinear",
  trControl = trainControl("cv", number = 3),
  tuneLength = 10
)

# Stop the clock
end_time=Sys.time()
## time elapsed calculation
time_elapsed=end_time-start_time
time_elapsed


##train error
library(caret)
train_pred=predict(svm.cv,train[,-15])

length(train_pred)
head(train_pred)
head(train$avg)

acc=confusionMatrix(as.factor(train_pred),as.factor(train[,15]),positive = "1")
acc

trainerror=1-acc$overall
trainerror

## test error
test_pred=predict(svm.cv,test[,-15])

acc=confusionMatrix(test_pred,as.factor(test[,15]),positive = "1")
acc

testerror=1-acc$overall
testerror




#######################################
######################################
#### DATASET-2 Rain In Australia
#####################################
### https://www.kaggle.com/jsphyg/weather-dataset-rattle-package


data2=read.csv("C:\\Users\\19726\\Desktop\\Applied Machine Learning\\Assignment-2\\weatherAUS.csv")

head(data2)
str(data2)
summary(data2)

data2$RISK_MM=NULL ## Given in the dataset that the RISK_MM variable should be removed as it has
## Not excluding it will leak the answers to your model and reduce its predictability.

## Finding NA's
sum(is.na(data2))
colSums(is.na(data2))

## Data Manipulation
data2$Date=NULL

## Removing variables with lot of missing values
data2$Evaporation=NULL
data2$Sunshine=NULL

library(zoo)
## imputing variables with previous values as it is time series data.
data2=na.locf(data2,fromLast=TRUE)

str(data2)
colSums(is.na(data2))

## Checking ratio of target variable responses
table(data2$RainTomorrow)

#### splitting the data set into test and train
set.seed(101) # Set Seed so that same sample can be reproduced in future also
# Now Selecting 70% of data as sample from total 'n' rows of the data  
sample <- sample.int(n = nrow(data2), size = floor(.70*nrow(data2)), replace = F)
train <- data2[sample, ]
test  <- data2[-sample, ]

##########################
### SVM
library(e1071)
#library(kernlab) #assist with SVM feature selection
str(train)

## start clock
start_time=Sys.time()
set.seed(100)

linear_svm = svm(RainTomorrow~., data=train, kernel="linear", gamma=0, cost=1)

# Stop the clock
end_time=Sys.time()
## time elapsed calculation
time_elapsed=end_time-start_time
time_elapsed

summary(linear_svm)

##train error
library(caret)
train_pred=predict(linear_svm,train[,-20])

length(train_pred)
head(train_pred)
head(train$RainTomorrow)

acc=confusionMatrix(as.factor(train_pred),as.factor(train[,20]),positive = "Yes")
acc

trainerror=1-acc$overall
trainerror

## test error
test_pred=predict(linear_svm,test[-20])

acc=confusionMatrix(test_pred,as.factor(test[,20]),positive = "Yes")
acc

testerror=1-acc$overall
testerror



#############################################
############# cross validation
#########################################
require(caret)
require(kernlab)

start_time=Sys.time()
caret.control=trainControl(method = "repeatedcv",
                           number = 10,
                           repeats=3)

set.seed(100)

svm.cv=train(RainTomorrow~.,
       data=train,
       method="svmLinear",
       trControl=caret.control,
       tuneLength=15)


# Stop the clock
end_time=Sys.time()
## time elapsed calculation
time_elapsed=end_time-start_time
time_elapsed


##train error
library(caret)
train_pred=predict(linear_svm,train[,-20])

length(train_pred)
head(train_pred)
head(train$RainTomorrow)

acc=confusionMatrix(as.factor(train_pred),as.factor(train[,20]),positive = "Yes")
acc

trainerror=1-acc$overall
trainerror

## test error
test_pred=predict(linear_svm,test[-20])

acc=confusionMatrix(test_pred,as.factor(test[,20]),positive = "Yes")
acc

testerror=1-acc$overall
testerror
